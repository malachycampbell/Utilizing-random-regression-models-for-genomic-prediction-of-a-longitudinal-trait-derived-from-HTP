This is all the data and code used in Campbell 2018.

- HTMLoutput: Output in HTML from Rmarkdown
- Phenotypes_raw: Raw phenotypic data for RDP1. Used in 1.Phenoprep.rmd
- Rmarkdownfiles: R code used for all analyses. ASREML examples are also provided.
- RR: Files and output used for RR model selection, and hertiability and genetic correlation
- ScenarioA: ASREML output for ScenarioA. See the corresponding Rmarkdown files for a description of the relevant files. All output is included for transparency.
- ScenarioB: ASREML output for ScenarioB. See the corresponding Rmarkdown files for a description of the relevant files. All output is included for transparency.
- ScenarioC: ASREML output for ScenarioC. See the corresponding Rmarkdown files for a description of the relevant files. All output is included for transparency.
- ScenarioD: Data for ScenarioD. Just consists of PSA data.
- TP: Data and output for hertiability and genomic prediction.